import { useEffect, useState } from 'react';
import { useStore } from '@/hooks/useStore';
import HomePage from '@/sections/HomePage';
import ChatPage from '@/sections/ChatPage';
import SettingsPage from '@/sections/SettingsPage';
import ImageGenPage from '@/sections/ImageGenPage';
import { Toaster } from '@/components/ui/sonner';

// Toast component
function ToastContainer() {
  const { toasts } = useStore();

  return (
    <div className="fixed bottom-4 right-4 z-50 space-y-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`px-4 py-3 rounded-xl shadow-lg flex items-center gap-3 min-w-[200px] animate-slide-up ${
            t.type === 'success' ? 'bg-green-500/90 text-white' :
            t.type === 'error' ? 'bg-red-500/90 text-white' :
            t.type === 'warning' ? 'bg-yellow-500/90 text-black' :
            'bg-white/90 text-black'
          }`}
        >
          {t.type === 'success' && (
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          )}
          {t.type === 'error' && (
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          )}
          {t.type === 'warning' && (
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          )}
          {t.type === 'info' && (
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          )}
          <span className="text-sm font-medium">{t.message}</span>
        </div>
      ))}
    </div>
  );
}

// Loading screen
function LoadingScreen() {
  return (
    <div className="fixed inset-0 bg-black flex items-center justify-center z-50">
      <div className="text-center">
        <div className="relative w-24 h-24 mx-auto mb-6">
          <div className="absolute inset-0 border-4 border-gray-800 rounded-full" />
          <div className="absolute inset-0 border-4 border-t-[#FF6B6B] border-r-[#4ECDC4] border-b-[#FFE66D] border-l-transparent rounded-full animate-spin" />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-2xl font-bold gradient-text">S</span>
          </div>
        </div>
        <h1 className="text-2xl font-bold mb-2">studioPRO v2</h1>
        <p className="text-gray-500">正在加载...</p>
      </div>
    </div>
  );
}

// Main App Component
function App() {
  const { currentPage, currentMode, setCurrentPage } = useStore();
  const [isLoading, setIsLoading] = useState(true);

  // Simulate initial loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  // Handle page visibility change
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.hidden) {
        // Save state when app is hidden
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
  }, []);

  // Render current page
  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'chat':
        // Route to image gen if in image mode
        if (currentMode === 'image') {
          return <ImageGenPage />;
        }
        return <ChatPage />;
      case 'settings':
        return <SettingsPage />;
      case 'history':
        // For now, redirect to home
        return <HomePage />;
      default:
        return <HomePage />;
    }
  };

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Main Content */}
      <main className="relative">
        {renderPage()}
      </main>

      {/* Toast Notifications */}
      <ToastContainer />
      <Toaster 
        position="bottom-right"
        toastOptions={{
          style: {
            background: '#1a1a1a',
            color: '#fff',
            border: '1px solid #333',
          },
        }}
      />

      {/* Mobile Navigation Bar */}
      <nav className={`fixed bottom-0 left-0 right-0 glass-strong border-t border-gray-800 lg:hidden z-40 transition-transform duration-300 ${
        currentPage === 'home' ? 'translate-y-full' : 'translate-y-0'
      }`}>
        <div className="flex items-center justify-around py-3">
          <button 
            onClick={() => setCurrentPage('home')}
            className={`flex flex-col items-center gap-1 p-2 ${currentPage === 'home' ? 'text-[#FF6B6B]' : 'text-gray-500'}`}
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
            </svg>
            <span className="text-xs">首页</span>
          </button>
          <button 
            onClick={() => setCurrentPage('chat')}
            className={`flex flex-col items-center gap-1 p-2 ${currentPage === 'chat' ? 'text-[#FF6B6B]' : 'text-gray-500'}`}
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <span className="text-xs">对话</span>
          </button>
          <button 
            onClick={() => setCurrentPage('settings')}
            className={`flex flex-col items-center gap-1 p-2 ${currentPage === 'settings' ? 'text-[#FF6B6B]' : 'text-gray-500'}`}
          >
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span className="text-xs">设置</span>
          </button>
        </div>
      </nav>

      {/* Add padding for mobile nav */}
      <div className={`h-20 lg:hidden transition-all duration-300 ${currentPage === 'home' ? 'h-0' : 'h-20'}`} />
    </div>
  );
}

export default App;
