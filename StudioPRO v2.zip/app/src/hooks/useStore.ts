import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { 
  AppSettings, 
  ChatSession, 
  Message, 
  AIMode, 
  GeneratedImage,
  APIConfig,
  AIPreset,
  Toast
} from '@/types';

interface AppState {
  // Navigation
  currentPage: 'home' | 'chat' | 'settings' | 'history';
  setCurrentPage: (page: 'home' | 'chat' | 'settings' | 'history') => void;
  
  // AI Mode
  currentMode: AIMode;
  setCurrentMode: (mode: AIMode) => void;
  
  // Chat Sessions
  sessions: ChatSession[];
  currentSessionId: string | null;
  createSession: (mode: AIMode, model: string, provider: string) => string;
  deleteSession: (id: string) => void;
  setCurrentSession: (id: string) => void;
  addMessage: (sessionId: string, message: Message) => void;
  updateMessage: (sessionId: string, messageId: string, content: string) => void;
  clearSessions: () => void;
  
  // Generated Images
  generatedImages: GeneratedImage[];
  addGeneratedImage: (image: GeneratedImage) => void;
  deleteGeneratedImage: (id: string) => void;
  clearGeneratedImages: () => void;
  
  // Settings
  settings: AppSettings;
  updateSettings: (settings: Partial<AppSettings>) => void;
  updateAPIConfig: (provider: string, config: Partial<APIConfig>) => void;
  
  // Presets
  presets: AIPreset[];
  selectedPresetId: string | null;
  setSelectedPreset: (id: string | null) => void;
  
  // UI State
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  isGenerating: boolean;
  setIsGenerating: (value: boolean) => void;
  
  // Toasts
  toasts: Toast[];
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
}

const defaultSettings: AppSettings = {
  theme: 'dark',
  language: 'zh-CN',
  defaultModel: 'gpt-4o-mini',
  defaultProvider: 'openai',
  apiConfigs: [
    {
      provider: 'openai',
      apiKey: '',
      apiUrl: 'https://api.openai.com/v1',
      model: 'gpt-4o-mini',
      enabled: true
    },
    {
      provider: 'anthropic',
      apiKey: '',
      apiUrl: 'https://api.anthropic.com/v1',
      model: 'claude-3-sonnet',
      enabled: false
    },
    {
      provider: 'gemini',
      apiKey: '',
      apiUrl: 'https://generativelanguage.googleapis.com/v1beta',
      model: 'gemini-pro',
      enabled: false
    },
    {
      provider: 'deepseek',
      apiKey: '',
      apiUrl: 'https://api.deepseek.com/v1',
      model: 'deepseek-chat',
      enabled: false
    },
    {
      provider: 'custom',
      apiKey: '',
      apiUrl: '',
      model: '',
      enabled: false
    }
  ],
  imageProvider: 'openai',
  imageApiKey: '',
  imageApiUrl: 'https://api.openai.com/v1',
  soundEnabled: true,
  vibrationEnabled: true,
  autoSave: true
};

const defaultPresets: AIPreset[] = [
  {
    id: 'chat',
    name: 'AI 聊天',
    description: '通用对话助手，回答各类问题',
    icon: 'MessageCircle',
    color: '#FF6B6B',
    mode: 'chat',
    systemPrompt: '你是一个 helpful 的 AI 助手，能够回答用户的各种问题。请用中文回复。',
    welcomeMessage: '你好！我是你的 AI 助手，有什么可以帮助你的吗？'
  },
  {
    id: 'coder',
    name: 'AI 编程',
    description: '专业代码助手，编写调试代码',
    icon: 'Code',
    color: '#4ECDC4',
    mode: 'coder',
    systemPrompt: '你是一个专业的编程助手，擅长各种编程语言。请提供清晰、高效的代码，并解释关键部分。使用中文回复。',
    welcomeMessage: '你好！我是你的编程助手，需要什么代码帮助吗？'
  },
  {
    id: 'image',
    name: 'AI 生图',
    description: '创意图像生成，释放想象力',
    icon: 'Image',
    color: '#FFE66D',
    mode: 'image',
    systemPrompt: '你是一个图像生成助手。请帮助用户优化他们的图像生成提示词，以获得更好的结果。',
    welcomeMessage: '你好！我可以帮你生成精美的图片，描述你想要的画面吧！'
  }
];

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Navigation
      currentPage: 'home',
      setCurrentPage: (page) => set({ currentPage: page }),
      
      // AI Mode
      currentMode: 'chat',
      setCurrentMode: (mode) => set({ currentMode: mode }),
      
      // Chat Sessions
      sessions: [],
      currentSessionId: null,
      createSession: (mode, model, provider) => {
        const id = Date.now().toString();
        const preset = defaultPresets.find(p => p.mode === mode);
        const newSession: ChatSession = {
          id,
          title: preset?.name || '新对话',
          messages: preset ? [{
            id: 'welcome',
            role: 'assistant',
            content: preset.welcomeMessage,
            timestamp: Date.now(),
            model
          }] : [],
          model,
          provider: provider as any,
          createdAt: Date.now(),
          updatedAt: Date.now()
        };
        set(state => ({
          sessions: [newSession, ...state.sessions],
          currentSessionId: id
        }));
        return id;
      },
      deleteSession: (id) => {
        set(state => ({
          sessions: state.sessions.filter(s => s.id !== id),
          currentSessionId: state.currentSessionId === id ? null : state.currentSessionId
        }));
      },
      setCurrentSession: (id) => set({ currentSessionId: id }),
      addMessage: (sessionId, message) => {
        set(state => ({
          sessions: state.sessions.map(s => 
            s.id === sessionId 
              ? { ...s, messages: [...s.messages, message], updatedAt: Date.now() }
              : s
          )
        }));
      },
      updateMessage: (sessionId, messageId, content) => {
        set(state => ({
          sessions: state.sessions.map(s => 
            s.id === sessionId 
              ? { 
                  ...s, 
                  messages: s.messages.map(m => 
                    m.id === messageId ? { ...m, content } : m
                  )
                }
              : s
          )
        }));
      },
      clearSessions: () => set({ sessions: [], currentSessionId: null }),
      
      // Generated Images
      generatedImages: [],
      addGeneratedImage: (image) => {
        set(state => ({
          generatedImages: [image, ...state.generatedImages]
        }));
      },
      deleteGeneratedImage: (id) => {
        set(state => ({
          generatedImages: state.generatedImages.filter(img => img.id !== id)
        }));
      },
      clearGeneratedImages: () => set({ generatedImages: [] }),
      
      // Settings
      settings: defaultSettings,
      updateSettings: (newSettings) => {
        set(state => ({
          settings: { ...state.settings, ...newSettings }
        }));
      },
      updateAPIConfig: (provider, config) => {
        set(state => ({
          settings: {
            ...state.settings,
            apiConfigs: state.settings.apiConfigs.map(c => 
              c.provider === provider ? { ...c, ...config } : c
            )
          }
        }));
      },
      
      // Presets
      presets: defaultPresets,
      selectedPresetId: null,
      setSelectedPreset: (id) => set({ selectedPresetId: id }),
      
      // UI State
      isSidebarOpen: false,
      toggleSidebar: () => set(state => ({ isSidebarOpen: !state.isSidebarOpen })),
      isGenerating: false,
      setIsGenerating: (value) => set({ isGenerating: value }),
      
      // Toasts
      toasts: [],
      addToast: (toast) => {
        const id = Date.now().toString();
        set(state => ({
          toasts: [...state.toasts, { ...toast, id }]
        }));
        setTimeout(() => {
          get().removeToast(id);
        }, toast.duration || 3000);
      },
      removeToast: (id) => {
        set(state => ({
          toasts: state.toasts.filter(t => t.id !== id)
        }));
      }
    }),
    {
      name: 'studio-pro-storage',
      partialize: (state) => ({
        sessions: state.sessions,
        settings: state.settings,
        generatedImages: state.generatedImages
      })
    }
  )
);
