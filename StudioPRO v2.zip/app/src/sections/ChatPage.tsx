import { useState, useRef, useEffect } from 'react';
import { 
  Send, 
  Plus, 
  Trash2, 
  Copy, 
  Check,
  Image as ImageIcon,
  Code,
  MessageCircle,
  ChevronLeft,
  Sparkles,
  StopCircle
} from 'lucide-react';
import { useStore } from '@/hooks/useStore';
import type { Message, AIMode } from '@/types';
import { generateId } from '@/lib/utils';

// Code block component with syntax highlighting
function CodeBlock({ code, language }: { code: string; language: string }) {
  const [copied, setCopied] = useState(false);

  const copyCode = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="code-block my-4 overflow-hidden">
      <div className="code-header flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="code-dot red" />
          <div className="code-dot yellow" />
          <div className="code-dot green" />
          <span className="ml-2 text-xs text-gray-400">{language || 'code'}</span>
        </div>
        <button 
          onClick={copyCode}
          className="p-1.5 hover:bg-white/10 rounded transition-colors"
        >
          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
        </button>
      </div>
      <pre className="p-4 overflow-x-auto text-sm font-mono text-gray-300">
        <code>{code}</code>
      </pre>
    </div>
  );
}

// Message content renderer
function MessageContent({ content }: { content: string }) {
  // Simple markdown-like parsing
  const parts = content.split(/(```[\s\S]*?```|`[^`]+`)/g);
  
  return (
    <div className="space-y-2">
      {parts.map((part, index) => {
        if (part.startsWith('```')) {
          const match = part.match(/```(\w*)\n?([\s\S]*?)```/);
          if (match) {
            const [, lang, code] = match;
            return <CodeBlock key={index} code={code.trim()} language={lang} />;
          }
        }
        if (part.startsWith('`') && part.endsWith('`')) {
          return (
            <code key={index} className="px-1.5 py-0.5 bg-white/10 rounded text-sm font-mono text-[#FFE66D]">
              {part.slice(1, -1)}
            </code>
          );
        }
        return <span key={index} className="whitespace-pre-wrap">{part}</span>;
      })}
    </div>
  );
}

// Message bubble component
function MessageBubble({ message, onDelete }: { message: Message; onDelete?: () => void }) {
  const isUser = message.role === 'user';
  const [showActions, setShowActions] = useState(false);

  return (
    <div 
      className={`flex gap-4 ${isUser ? 'flex-row-reverse' : ''} group`}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      {/* Avatar */}
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
        isUser 
          ? 'bg-gradient-to-br from-[#FF6B6B] to-[#ff8e8e]' 
          : 'bg-gradient-to-br from-[#4ECDC4] to-[#6ee0d8]'
      }`}>
        {isUser ? (
          <span className="text-black font-semibold text-sm">我</span>
        ) : (
          <Sparkles className="w-5 h-5 text-black" />
        )}
      </div>

      {/* Message */}
      <div className={`flex-1 max-w-[85%] ${isUser ? 'text-right' : ''}`}>
        <div className={`inline-block text-left ${isUser ? 'message-user' : 'message-ai'} px-5 py-3`}>
          <MessageContent content={message.content} />
        </div>
        
        {/* Actions */}
        {showActions && (
          <div className={`flex gap-2 mt-2 ${isUser ? 'justify-end' : ''}`}>
            <button 
              onClick={() => navigator.clipboard.writeText(message.content)}
              className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
              title="复制"
            >
              <Copy className="w-4 h-4 text-gray-500" />
            </button>
            {onDelete && (
              <button 
                onClick={onDelete}
                className="p-1.5 hover:bg-white/10 rounded-lg transition-colors"
                title="删除"
              >
                <Trash2 className="w-4 h-4 text-gray-500" />
              </button>
            )}
          </div>
        )}
        
        {/* Timestamp */}
        <div className="text-xs text-gray-600 mt-1">
          {new Date(message.timestamp).toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
}

// Typing indicator
function TypingIndicator() {
  return (
    <div className="flex gap-4">
      <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-[#4ECDC4] to-[#6ee0d8] flex items-center justify-center">
        <Sparkles className="w-5 h-5 text-black" />
      </div>
      <div className="message-ai px-5 py-4 flex items-center gap-2">
        <span className="w-2 h-2 bg-gray-500 rounded-full animate-typing" style={{ animationDelay: '0s' }} />
        <span className="w-2 h-2 bg-gray-500 rounded-full animate-typing" style={{ animationDelay: '0.2s' }} />
        <span className="w-2 h-2 bg-gray-500 rounded-full animate-typing" style={{ animationDelay: '0.4s' }} />
      </div>
    </div>
  );
}

// Mode selector
function ModeSelector({ currentMode, onModeChange }: { currentMode: AIMode; onModeChange: (mode: AIMode) => void }) {
  const modes: { id: AIMode; name: string; icon: any; color: string }[] = [
    { id: 'chat', name: '聊天', icon: MessageCircle, color: '#FF6B6B' },
    { id: 'coder', name: '编程', icon: Code, color: '#4ECDC4' },
    { id: 'image', name: '生图', icon: ImageIcon, color: '#FFE66D' }
  ];

  return (
    <div className="flex gap-2 p-1.5 bg-white/5 rounded-xl">
      {modes.map(mode => {
        const Icon = mode.icon;
        const isActive = currentMode === mode.id;
        return (
          <button
            key={mode.id}
            onClick={() => onModeChange(mode.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 ${
              isActive 
                ? 'text-black font-medium' 
                : 'text-gray-400 hover:text-white hover:bg-white/5'
            }`}
            style={{ background: isActive ? mode.color : 'transparent' }}
          >
            <Icon className="w-4 h-4" />
            <span className="text-sm">{mode.name}</span>
          </button>
        );
      })}
    </div>
  );
}

export default function ChatPage() {
  const { 
    currentMode, 
    setCurrentMode,
    setCurrentPage,
    sessions,
    currentSessionId,
    createSession,
    addMessage,
    settings,
    isGenerating,
    setIsGenerating,
    addToast
  } = useStore();

  const [input, setInput] = useState('');
  const [streamingContent, setStreamingContent] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const currentSession = sessions.find(s => s.id === currentSessionId);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [currentSession?.messages, streamingContent]);

  // Auto-resize textarea
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  // Create new session if none exists
  useEffect(() => {
    if (!currentSessionId && settings.defaultModel) {
      const activeConfig = settings.apiConfigs.find(c => c.enabled && c.apiKey);
      if (activeConfig) {
        createSession(currentMode, activeConfig.model, activeConfig.provider);
      }
    }
  }, [currentSessionId, settings]);

  const handleSend = async () => {
    if (!input.trim() || isGenerating) return;

    const activeConfig = settings.apiConfigs.find(c => c.enabled && c.apiKey);
    if (!activeConfig) {
      addToast({ type: 'error', message: '请先配置 API 密钥' });
      setCurrentPage('settings');
      return;
    }

    // Create session if needed
    let sessionId = currentSessionId;
    if (!sessionId) {
      sessionId = createSession(currentMode, activeConfig.model, activeConfig.provider);
    }

    // Add user message
    const userMessage: Message = {
      id: generateId(),
      role: 'user',
      content: input.trim(),
      timestamp: Date.now()
    };
    addMessage(sessionId, userMessage);
    setInput('');

    // Start generation
    setIsGenerating(true);
    setStreamingContent('');

    try {
      const abortController = new AbortController();
      abortControllerRef.current = abortController;

      // Build messages for API
      const messages = currentSession 
        ? [...currentSession.messages, userMessage].map(m => ({
            role: m.role,
            content: m.content
          }))
        : [{ role: 'user', content: input.trim() }];

      // Call API based on provider
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          provider: activeConfig.provider,
          apiKey: activeConfig.apiKey,
          apiUrl: activeConfig.apiUrl,
          model: activeConfig.model,
          messages
        }),
        signal: abortController.signal
      });

      if (!response.ok) {
        throw new Error('API request failed');
      }

      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullContent = '';

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          const chunk = decoder.decode(value);
          const lines = chunk.split('\n');
          
          for (const line of lines) {
            if (line.startsWith('data: ')) {
              const data = line.slice(6);
              if (data === '[DONE]') continue;
              
              try {
                const parsed = JSON.parse(data);
                const content = parsed.choices?.[0]?.delta?.content || '';
                fullContent += content;
                setStreamingContent(fullContent);
              } catch (e) {
                // Ignore parse errors
              }
            }
          }
        }
      }

      // Add assistant message
      const assistantMessage: Message = {
        id: generateId(),
        role: 'assistant',
        content: fullContent,
        timestamp: Date.now(),
        model: activeConfig.model
      };
      addMessage(sessionId, assistantMessage);

    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        // User cancelled
      } else {
        addToast({ type: 'error', message: '生成失败，请检查 API 配置' });
      }
    } finally {
      setIsGenerating(false);
      setStreamingContent('');
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    abortControllerRef.current?.abort();
    setIsGenerating(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleNewChat = () => {
    const activeConfig = settings.apiConfigs.find(c => c.enabled && c.apiKey);
    if (activeConfig) {
      createSession(currentMode, activeConfig.model, activeConfig.provider);
    } else {
      addToast({ type: 'error', message: '请先配置 API 密钥' });
      setCurrentPage('settings');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-black">
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-gray-800 glass-strong">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setCurrentPage('home')}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="font-semibold">AI 对话</h1>
            <p className="text-xs text-gray-500">
              {currentSession?.model || settings.defaultModel}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <ModeSelector currentMode={currentMode} onModeChange={setCurrentMode} />
          <button 
            onClick={handleNewChat}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors ml-2"
            title="新对话"
          >
            <Plus className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {currentSession?.messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-[#FF6B6B]/20 to-[#4ECDC4]/20 flex items-center justify-center mb-6">
              <Sparkles className="w-10 h-10 text-[#FF6B6B]" />
            </div>
            <h2 className="text-2xl font-bold mb-2">开始对话</h2>
            <p className="text-gray-500 max-w-md">
              输入你的问题或需求，AI 助手将为你提供帮助
            </p>
          </div>
        )}

        {currentSession?.messages.map((message) => (
          <MessageBubble 
            key={message.id} 
            message={message}
            onDelete={() => {
              // Delete message logic
            }}
          />
        ))}

        {isGenerating && streamingContent && (
          <MessageBubble 
            message={{
              id: 'streaming',
              role: 'assistant',
              content: streamingContent,
              timestamp: Date.now()
            }}
          />
        )}

        {isGenerating && !streamingContent && <TypingIndicator />}

        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 border-t border-gray-800 glass-strong">
        <div className="max-w-4xl mx-auto">
          <div className="relative">
            <textarea
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="输入消息... (Shift+Enter 换行)"
              className="input-glow w-full pr-24 resize-none min-h-[56px] max-h-[200px]"
              rows={1}
              disabled={isGenerating}
            />
            <div className="absolute right-2 bottom-2 flex gap-2">
              {isGenerating ? (
                <button 
                  onClick={handleStop}
                  className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                >
                  <StopCircle className="w-5 h-5" />
                </button>
              ) : (
                <button 
                  onClick={handleSend}
                  disabled={!input.trim()}
                  className="p-2 bg-gradient-to-r from-[#FF6B6B] to-[#ff8e8e] text-black rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Send className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
          <p className="text-xs text-gray-600 mt-2 text-center">
            AI 生成的内容仅供参考，请核实重要信息
          </p>
        </div>
      </div>
    </div>
  );
}
