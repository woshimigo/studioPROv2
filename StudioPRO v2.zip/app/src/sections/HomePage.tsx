import { useEffect, useRef, useState } from 'react';
import { 
  MessageCircle, 
  Code, 
  Image, 
  Sparkles, 
  Zap, 
  Shield, 
  Settings,
  ChevronRight,
  Cpu,
  Globe
} from 'lucide-react';
import { useStore } from '@/hooks/useStore';
import type { AIMode } from '@/types';

const modeCards: { id: AIMode; name: string; description: string; icon: any; color: string; gradient: string }[] = [
  {
    id: 'chat',
    name: 'AI 聊天',
    description: '智能对话，解答万物',
    icon: MessageCircle,
    color: '#FF6B6B',
    gradient: 'from-[#FF6B6B] to-[#ff8e8e]'
  },
  {
    id: 'coder',
    name: 'AI 编程',
    description: '代码生成，调试优化',
    icon: Code,
    color: '#4ECDC4',
    gradient: 'from-[#4ECDC4] to-[#6ee0d8]'
  },
  {
    id: 'image',
    name: 'AI 生图',
    description: '创意绘图，无限想象',
    icon: Image,
    color: '#FFE66D',
    gradient: 'from-[#FFE66D] to-[#fff0a0]'
  }
];

const features = [
  { icon: Zap, title: '极速响应', desc: '流式输出，实时反馈' },
  { icon: Shield, title: '隐私安全', desc: '本地存储，数据加密' },
  { icon: Cpu, title: '多模态', desc: '文本、代码、图像' },
  { icon: Globe, title: '多平台', desc: '支持各大 AI 平台' }
];

const stats = [
  { value: '10+', label: 'AI 模型' },
  { value: '3', label: '创作模式' },
  { value: '100%', label: '免费开源' },
  { value: '0', label: '广告干扰' }
];

export default function HomePage() {
  const { setCurrentPage, setCurrentMode, settings } = useStore();
  const containerRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleModeSelect = (mode: AIMode) => {
    setCurrentMode(mode);
    setCurrentPage('chat');
  };

  const hasApiKey = settings.apiConfigs.some(c => c.apiKey && c.enabled);

  return (
    <div 
      ref={containerRef}
      className="min-h-screen bg-black text-white overflow-x-hidden"
    >
      {/* Hero Section */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-6 py-20 overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 overflow-hidden">
          {/* Gradient Orbs */}
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#FF6B6B]/20 rounded-full blur-[120px] animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#4ECDC4]/20 rounded-full blur-[120px] animate-pulse" style={{ animationDelay: '1s' }} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#FFE66D]/10 rounded-full blur-[150px] animate-pulse" style={{ animationDelay: '2s' }} />
          
          {/* Grid Pattern */}
          <div 
            className="absolute inset-0 opacity-[0.03]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                               linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
              backgroundSize: '50px 50px'
            }}
          />
        </div>

        {/* Content */}
        <div className={`relative z-10 text-center max-w-4xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8">
            <Sparkles className="w-4 h-4 text-[#FFE66D]" />
            <span className="text-sm text-gray-300">免费开源 · 无广告 · 多平台</span>
          </div>

          {/* Title */}
          <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold mb-6 tracking-tight">
            <span className="gradient-text">studioPRO</span>
            <span className="text-white"> v2</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl sm:text-2xl text-gray-400 mb-4 max-w-2xl mx-auto">
            下一代 AI 创作工作台
          </p>
          <p className="text-base text-gray-500 mb-12 max-w-xl mx-auto">
            在一个强大的工作空间中整合编码、设计和对话。支持 OpenAI、Claude、Gemini 等主流 AI 平台。
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button 
              onClick={() => handleModeSelect('chat')}
              className="btn-primary flex items-center justify-center gap-2 text-lg"
            >
              <Sparkles className="w-5 h-5" />
              开始创作
              <ChevronRight className="w-5 h-5" />
            </button>
            <button 
              onClick={() => setCurrentPage('settings')}
              className="btn-secondary flex items-center justify-center gap-2 text-lg"
            >
              <Settings className="w-5 h-5" />
              配置 API
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-2xl mx-auto">
            {stats.map((stat, index) => (
              <div 
                key={index}
                className="text-center"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="text-3xl font-bold gradient-text mb-1">{stat.value}</div>
                <div className="text-sm text-gray-500">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-gray-600 flex justify-center pt-2">
            <div className="w-1.5 h-3 bg-gray-500 rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Mode Selection Section */}
      <section className="relative py-24 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">选择创作模式</h2>
            <p className="text-gray-400 max-w-xl mx-auto">
              根据你的需求选择合适的 AI 模式，开启智能创作之旅
            </p>
          </div>

          {/* Mode Cards */}
          <div className="grid md:grid-cols-3 gap-6">
            {modeCards.map((mode, index) => {
              const Icon = mode.icon;
              return (
                <div
                  key={mode.id}
                  onClick={() => handleModeSelect(mode.id)}
                  className="group relative cursor-pointer"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  {/* Card Glow */}
                  <div 
                    className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl"
                    style={{ background: mode.color }}
                  />
                  
                  {/* Card Content */}
                  <div className="relative glass rounded-3xl p-8 h-full card-hover border border-gray-800 group-hover:border-gray-600 transition-colors">
                    {/* Icon */}
                    <div 
                      className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${mode.gradient} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}
                    >
                      <Icon className="w-8 h-8 text-black" />
                    </div>

                    {/* Text */}
                    <h3 className="text-2xl font-bold mb-2">{mode.name}</h3>
                    <p className="text-gray-400 mb-6">{mode.description}</p>

                    {/* Arrow */}
                    <div className="flex items-center gap-2 text-gray-500 group-hover:text-white transition-colors">
                      <span className="text-sm">立即体验</span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="relative py-24 px-6">
        <div className="max-w-6xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">为什么选择 studioPRO</h2>
            <p className="text-gray-400 max-w-xl mx-auto">
              我们致力于提供最纯粹的 AI 创作体验
            </p>
          </div>

          {/* Feature Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="glass rounded-2xl p-6 text-center card-hover"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-6 h-6 text-[#FF6B6B]" />
                  </div>
                  <h3 className="font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-gray-500">{feature.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* API Setup CTA */}
      {!hasApiKey && (
        <section className="relative py-24 px-6">
          <div className="max-w-4xl mx-auto">
            <div className="glass rounded-3xl p-8 md:p-12 text-center relative overflow-hidden">
              {/* Background Glow */}
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-[#FF6B6B]/10 rounded-full blur-[100px]" />
              
              <div className="relative z-10">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#FF6B6B] to-[#ff8e8e] flex items-center justify-center mx-auto mb-6">
                  <Settings className="w-8 h-8 text-black" />
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-4">配置你的 API 密钥</h2>
                <p className="text-gray-400 mb-8 max-w-lg mx-auto">
                  添加你的 AI 平台 API 密钥即可开始使用。我们支持 OpenAI、Anthropic、Gemini 等多个平台。
                </p>
                <button 
                  onClick={() => setCurrentPage('settings')}
                  className="btn-primary"
                >
                  前往设置
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="relative py-12 px-6 border-t border-gray-900">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#FF6B6B] to-[#4ECDC4] flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-lg">studioPRO v2</span>
            </div>

            {/* Links */}
            <div className="flex items-center gap-6 text-sm text-gray-500">
              <span>免费开源</span>
              <span>·</span>
              <span>无广告</span>
              <span>·</span>
              <span>隐私优先</span>
            </div>

            {/* Copyright */}
            <div className="text-sm text-gray-600">
              © 2024 studioPRO
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
