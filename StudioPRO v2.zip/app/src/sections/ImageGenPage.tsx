import { useState } from 'react';
import { 
  Image as ImageIcon, 
  Sparkles, 
  Download, 
  Trash2, 
  RefreshCw,
  Wand2,
  ChevronLeft,
  Settings,
  X,
  Loader2
} from 'lucide-react';
import { useStore } from '@/hooks/useStore';
import { generateId } from '@/lib/utils';

const imageStyles = [
  { id: 'realistic', name: '写实', icon: '📷' },
  { id: 'anime', name: '动漫', icon: '🎨' },
  { id: 'digital', name: '数字艺术', icon: '✨' },
  { id: 'oil', name: '油画', icon: '🖼️' },
  { id: 'sketch', name: '素描', icon: '✏️' },
  { id: '3d', name: '3D 渲染', icon: '🎭' }
];

const aspectRatios = [
  { id: '1:1', name: '1:1', width: 1024, height: 1024 },
  { id: '4:3', name: '4:3', width: 1024, height: 768 },
  { id: '3:4', name: '3:4', width: 768, height: 1024 },
  { id: '16:9', name: '16:9', width: 1024, height: 576 },
  { id: '9:16', name: '9:16', width: 576, height: 1024 }
];

const samplePrompts = [
  '一只可爱的橘猫在夕阳下的窗台上睡觉',
  '未来城市的夜景，霓虹灯闪烁，赛博朋克风格',
  '一片樱花树林，花瓣飘落，梦幻般的场景',
  '一座悬浮在空中的岛屿，瀑布流下，奇幻风格',
  '宇航员在火星表面行走，地球在远处升起'
];

export default function ImageGenPage() {
  const { 
    setCurrentPage, 
    settings, 
    generatedImages, 
    addGeneratedImage, 
    deleteGeneratedImage,
    addToast 
  } = useStore();

  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [selectedRatio, setSelectedRatio] = useState('1:1');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      addToast({ type: 'error', message: '请输入描述' });
      return;
    }

    const activeConfig = settings.apiConfigs.find(c => c.enabled && c.apiKey);
    if (!activeConfig) {
      addToast({ type: 'error', message: '请先配置 API 密钥' });
      setCurrentPage('settings');
      return;
    }

    setIsGenerating(true);
    setGeneratedImage(null);

    try {
      // For demo, we'll use a placeholder image generation
      // In production, this would call the actual image generation API
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Generate a placeholder image with the prompt text
      const canvas = document.createElement('canvas');
      const ratio = aspectRatios.find(r => r.id === selectedRatio);
      canvas.width = ratio?.width || 1024;
      canvas.height = ratio?.height || 1024;
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        // Create gradient background
        const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
        gradient.addColorStop(0, '#FF6B6B');
        gradient.addColorStop(0.5, '#4ECDC4');
        gradient.addColorStop(1, '#FFE66D');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Add text
        ctx.fillStyle = 'rgba(0,0,0,0.7)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        ctx.fillStyle = 'white';
        ctx.font = 'bold 48px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('AI Generated', canvas.width / 2, canvas.height / 2 - 50);
        
        ctx.font = '32px sans-serif';
        ctx.fillStyle = '#FF6B6B';
        ctx.fillText(prompt.slice(0, 30) + '...', canvas.width / 2, canvas.height / 2 + 20);
        
        ctx.font = '24px sans-serif';
        ctx.fillStyle = '#4ECDC4';
        ctx.fillText(`Style: ${selectedStyle}`, canvas.width / 2, canvas.height / 2 + 70);
        
        const imageUrl = canvas.toDataURL('image/png');
        setGeneratedImage(imageUrl);
        
        // Save to history
        const newImage = {
          id: generateId(),
          url: imageUrl,
          prompt: prompt.trim(),
          timestamp: Date.now(),
          params: {
            prompt: prompt.trim(),
            negativePrompt,
            style: selectedStyle,
            width: ratio?.width,
            height: ratio?.height
          }
        };
        addGeneratedImage(newImage);
        addToast({ type: 'success', message: '图片生成成功' });
      }
    } catch (error) {
      addToast({ type: 'error', message: '生成失败，请重试' });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = (url: string, filename?: string) => {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || `studio-pro-image-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    addToast({ type: 'success', message: '图片已下载' });
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 glass-strong border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setCurrentPage('home')}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold">AI 生图</h1>
              <p className="text-xs text-gray-500">创意绘图，无限想象</p>
            </div>
          </div>
          <button 
            onClick={() => setCurrentPage('settings')}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </header>

      <div className="flex flex-col lg:flex-row">
        {/* Left Panel - Controls */}
        <div className="lg:w-1/3 lg:max-w-md p-4 space-y-6 lg:h-[calc(100vh-80px)] lg:overflow-y-auto">
          {/* Prompt Input */}
          <div className="glass rounded-2xl p-6 border border-gray-800">
            <label className="block text-sm font-medium mb-3 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#FF6B6B]" />
              图片描述
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="描述你想要的画面..."
              className="input-glow w-full h-32 resize-none mb-4"
            />
            
            {/* Sample Prompts */}
            <div className="flex flex-wrap gap-2">
              {samplePrompts.map((sample, index) => (
                <button
                  key={index}
                  onClick={() => setPrompt(sample)}
                  className="text-xs px-3 py-1.5 bg-white/5 rounded-full text-gray-400 hover:bg-white/10 hover:text-white transition-colors"
                >
                  {sample.slice(0, 15)}...
                </button>
              ))}
            </div>
          </div>

          {/* Style Selection */}
          <div className="glass rounded-2xl p-6 border border-gray-800">
            <label className="block text-sm font-medium mb-3">图像风格</label>
            <div className="grid grid-cols-3 gap-2">
              {imageStyles.map(style => (
                <button
                  key={style.id}
                  onClick={() => setSelectedStyle(style.id)}
                  className={`p-3 rounded-xl text-center transition-all ${
                    selectedStyle === style.id
                      ? 'bg-gradient-to-r from-[#FF6B6B] to-[#ff8e8e] text-black'
                      : 'bg-white/5 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  <span className="text-2xl mb-1 block">{style.icon}</span>
                  <span className="text-xs">{style.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio */}
          <div className="glass rounded-2xl p-6 border border-gray-800">
            <label className="block text-sm font-medium mb-3">画面比例</label>
            <div className="flex gap-2">
              {aspectRatios.map(ratio => (
                <button
                  key={ratio.id}
                  onClick={() => setSelectedRatio(ratio.id)}
                  className={`flex-1 p-3 rounded-xl text-center transition-all ${
                    selectedRatio === ratio.id
                      ? 'bg-gradient-to-r from-[#4ECDC4] to-[#6ee0d8] text-black'
                      : 'bg-white/5 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  <span className="text-sm font-medium">{ratio.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Negative Prompt */}
          <div className="glass rounded-2xl p-6 border border-gray-800">
            <label className="block text-sm font-medium mb-3 text-gray-400">
              负面描述（可选）
            </label>
            <input
              type="text"
              value={negativePrompt}
              onChange={(e) => setNegativePrompt(e.target.value)}
              placeholder="不希望在画面中出现的内容..."
              className="input-glow w-full"
            />
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className="w-full btn-primary py-4 text-lg flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                生成中...
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                生成图片
              </>
            )}
          </button>
        </div>

        {/* Right Panel - Preview & History */}
        <div className="flex-1 p-4 lg:h-[calc(100vh-80px)] lg:overflow-y-auto">
          {/* Generated Image Preview */}
          {(generatedImage || isGenerating) && (
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4">生成结果</h3>
              <div className="glass rounded-2xl p-4 border border-gray-800">
                {isGenerating ? (
                  <div className="aspect-square max-w-lg mx-auto flex items-center justify-center">
                    <div className="text-center">
                      <div className="relative w-24 h-24 mx-auto mb-4">
                        <div className="absolute inset-0 border-4 border-gray-800 rounded-full" />
                        <div className="absolute inset-0 border-4 border-t-[#FF6B6B] border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin" />
                        <Sparkles className="absolute inset-0 m-auto w-8 h-8 text-[#FF6B6B]" />
                      </div>
                      <p className="text-gray-400">正在创作你的作品...</p>
                      <p className="text-sm text-gray-600 mt-2">这可能需要几秒钟</p>
                    </div>
                  </div>
                ) : (
                  <div className="relative">
                    <img 
                      src={generatedImage!} 
                      alt="Generated" 
                      className="w-full max-w-lg mx-auto rounded-xl"
                    />
                    <div className="flex justify-center gap-3 mt-4">
                      <button
                        onClick={() => handleDownload(generatedImage!)}
                        className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
                      >
                        <Download className="w-4 h-4" />
                        下载
                      </button>
                      <button
                        onClick={handleGenerate}
                        className="flex items-center gap-2 px-4 py-2 bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
                      >
                        <RefreshCw className="w-4 h-4" />
                        重新生成
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* History */}
          {generatedImages.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold mb-4">历史记录</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {generatedImages.map((image) => (
                  <div 
                    key={image.id} 
                    className="group relative glass rounded-xl overflow-hidden border border-gray-800 cursor-pointer"
                    onClick={() => setSelectedImage(image.url)}
                  >
                    <img 
                      src={image.url} 
                      alt={image.prompt}
                      className="w-full aspect-square object-cover"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDownload(image.url);
                        }}
                        className="p-2 bg-white/20 rounded-lg hover:bg-white/30 transition-colors"
                      >
                        <Download className="w-5 h-5" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteGeneratedImage(image.id);
                        }}
                        className="p-2 bg-red-500/20 rounded-lg hover:bg-red-500/30 transition-colors"
                      >
                        <Trash2 className="w-5 h-5 text-red-400" />
                      </button>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black to-transparent">
                      <p className="text-xs text-gray-300 truncate">{image.prompt}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Empty State */}
          {!generatedImage && generatedImages.length === 0 && !isGenerating && (
            <div className="h-full flex items-center justify-center">
              <div className="text-center">
                <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-[#FF6B6B]/20 to-[#4ECDC4]/20 flex items-center justify-center mx-auto mb-6">
                  <ImageIcon className="w-16 h-16 text-[#FF6B6B]" />
                </div>
                <h3 className="text-2xl font-bold mb-2">开始创作</h3>
                <p className="text-gray-500 max-w-md">
                  在左侧输入描述，选择风格和比例，点击生成按钮创建你的 AI 艺术作品
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Image Preview Modal */}
      {selectedImage && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-sm"
          onClick={() => setSelectedImage(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh]">
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute -top-12 right-0 p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <img 
              src={selectedImage} 
              alt="Preview" 
              className="max-w-full max-h-[85vh] rounded-2xl"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
        </div>
      )}
    </div>
  );
}
