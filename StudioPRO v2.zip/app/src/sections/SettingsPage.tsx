import { useState } from 'react';
import { 
  ChevronLeft, 
  Key, 
  Eye, 
  EyeOff, 
  Check, 
  AlertCircle,
  Palette,
  Volume2,
  Save,
  RefreshCw,
  Trash2,
  ExternalLink
} from 'lucide-react';
import { useStore } from '@/hooks/useStore';
import type { AIProvider } from '@/types';

const providers: { id: AIProvider; name: string; defaultUrl: string; models: string[] }[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    defaultUrl: 'https://api.openai.com/v1',
    models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo']
  },
  {
    id: 'anthropic',
    name: 'Anthropic (Claude)',
    defaultUrl: 'https://api.anthropic.com/v1',
    models: ['claude-3-5-sonnet-latest', 'claude-3-opus-latest', 'claude-3-sonnet-20240229']
  },
  {
    id: 'gemini',
    name: 'Google Gemini',
    defaultUrl: 'https://generativelanguage.googleapis.com/v1beta',
    models: ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-pro']
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    defaultUrl: 'https://api.deepseek.com/v1',
    models: ['deepseek-chat', 'deepseek-coder']
  },
  {
    id: 'custom',
    name: '自定义 API',
    defaultUrl: '',
    models: []
  }
];

function APIConfigCard({ 
  config, 
  onUpdate 
}: { 
  config: any; 
  onUpdate: (updates: any) => void;
}) {
  const [showKey, setShowKey] = useState(false);
  const provider = providers.find(p => p.id === config.provider);

  return (
    <div className="glass rounded-2xl p-6 border border-gray-800">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
            config.enabled ? 'bg-green-500/20' : 'bg-gray-800'
          }`}>
            <Key className={`w-5 h-5 ${config.enabled ? 'text-green-400' : 'text-gray-500'}`} />
          </div>
          <div>
            <h3 className="font-semibold">{provider?.name}</h3>
            <p className="text-sm text-gray-500">
              {config.enabled ? '已启用' : '未启用'}
            </p>
          </div>
        </div>
        <label className="relative inline-flex items-center cursor-pointer">
          <input 
            type="checkbox" 
            checked={config.enabled}
            onChange={(e) => onUpdate({ enabled: e.target.checked })}
            className="sr-only peer"
          />
          <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#FF6B6B]" />
        </label>
      </div>

      <div className="space-y-4">
        {/* API Key */}
        <div>
          <label className="block text-sm text-gray-400 mb-2">API 密钥</label>
          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={config.apiKey}
              onChange={(e) => onUpdate({ apiKey: e.target.value })}
              placeholder={`输入 ${provider?.name} API 密钥`}
              className="input-glow w-full pr-12"
            />
            <button
              onClick={() => setShowKey(!showKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 hover:bg-white/10 rounded transition-colors"
            >
              {showKey ? <EyeOff className="w-4 h-4 text-gray-500" /> : <Eye className="w-4 h-4 text-gray-500" />}
            </button>
          </div>
        </div>

        {/* API URL */}
        <div>
          <label className="block text-sm text-gray-400 mb-2">API 地址</label>
          <input
            type="text"
            value={config.apiUrl}
            onChange={(e) => onUpdate({ apiUrl: e.target.value })}
            placeholder={provider?.defaultUrl}
            className="input-glow w-full"
          />
        </div>

        {/* Model Selection */}
        <div>
          <label className="block text-sm text-gray-400 mb-2">默认模型</label>
          {provider?.models.length ? (
            <select
              value={config.model}
              onChange={(e) => onUpdate({ model: e.target.value })}
              className="input-glow w-full appearance-none cursor-pointer"
            >
              {provider.models.map(model => (
                <option key={model} value={model}>{model}</option>
              ))}
            </select>
          ) : (
            <input
              type="text"
              value={config.model}
              onChange={(e) => onUpdate({ model: e.target.value })}
              placeholder="输入模型名称"
              className="input-glow w-full"
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const { 
    settings, 
    updateSettings, 
    updateAPIConfig, 
    setCurrentPage,
    clearSessions,
    clearGeneratedImages,
    addToast
  } = useStore();

  const [activeTab, setActiveTab] = useState<'api' | 'general' | 'about'>('api');
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleSave = () => {
    addToast({ type: 'success', message: '设置已保存' });
  };

  const handleReset = () => {
    clearSessions();
    clearGeneratedImages();
    localStorage.removeItem('studio-pro-storage');
    window.location.reload();
  };

  const hasEnabledConfig = settings.apiConfigs.some(c => c.enabled && c.apiKey);

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 glass-strong border-b border-gray-800">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setCurrentPage('home')}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <h1 className="text-xl font-bold">设置</h1>
          </div>
          <button 
            onClick={handleSave}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <Save className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex px-4 border-t border-gray-800">
          {[
            { id: 'api', label: 'API 配置', icon: Key },
            { id: 'general', label: '通用', icon: Palette },
            { id: 'about', label: '关于', icon: ExternalLink }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors ${
                  isActive 
                    ? 'border-[#FF6B6B] text-[#FF6B6B]' 
                    : 'border-transparent text-gray-500 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Content */}
      <main className="p-4 max-w-4xl mx-auto">
        {/* API Config Tab */}
        {activeTab === 'api' && (
          <div className="space-y-6">
            {/* Status Card */}
            <div className={`glass rounded-2xl p-6 border ${
              hasEnabledConfig ? 'border-green-500/30 bg-green-500/5' : 'border-yellow-500/30 bg-yellow-500/5'
            }`}>
              <div className="flex items-start gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  hasEnabledConfig ? 'bg-green-500/20' : 'bg-yellow-500/20'
                }`}>
                  {hasEnabledConfig ? (
                    <Check className="w-5 h-5 text-green-400" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-yellow-400" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold mb-1">
                    {hasEnabledConfig ? 'API 已配置' : '需要配置 API'}
                  </h3>
                  <p className="text-sm text-gray-400">
                    {hasEnabledConfig 
                      ? '你已成功配置 AI API，可以开始使用了。' 
                      : '请至少配置一个 AI 平台的 API 密钥才能使用对话功能。'}
                  </p>
                </div>
              </div>
            </div>

            {/* Provider Cards */}
            <div className="space-y-4">
              {settings.apiConfigs.map(config => (
                <APIConfigCard
                  key={config.provider}
                  config={config}
                  onUpdate={(updates) => updateAPIConfig(config.provider, updates)}
                />
              ))}
            </div>

            {/* Tips */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-[#FFE66D]" />
                使用提示
              </h3>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>• API 密钥仅存储在本地，不会上传到任何服务器</li>
                <li>• 你可以同时启用多个 API，切换时自动使用已启用的配置</li>
                <li>• 自定义 API 支持任何兼容 OpenAI 格式的 API 服务</li>
                <li>• 建议定期更新 API 密钥以保证安全</li>
              </ul>
            </div>
          </div>
        )}

        {/* General Tab */}
        {activeTab === 'general' && (
          <div className="space-y-6">
            {/* Appearance */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-6 flex items-center gap-2">
                <Palette className="w-5 h-5 text-[#FF6B6B]" />
                外观
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">主题</p>
                    <p className="text-sm text-gray-500">选择应用主题</p>
                  </div>
                  <select
                    value={settings.theme}
                    onChange={(e) => updateSettings({ theme: e.target.value as any })}
                    className="input-glow appearance-none cursor-pointer"
                  >
                    <option value="dark">深色</option>
                    <option value="light">浅色</option>
                    <option value="auto">跟随系统</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Sound & Haptics */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-6 flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-[#4ECDC4]" />
                声音与振动
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">声音效果</p>
                    <p className="text-sm text-gray-500">播放操作音效</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={settings.soundEnabled}
                      onChange={(e) => updateSettings({ soundEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#4ECDC4]" />
                  </label>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">振动反馈</p>
                    <p className="text-sm text-gray-500">操作时振动</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={settings.vibrationEnabled}
                      onChange={(e) => updateSettings({ vibrationEnabled: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#4ECDC4]" />
                  </label>
                </div>
              </div>
            </div>

            {/* Data */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-6 flex items-center gap-2">
                <RefreshCw className="w-5 h-5 text-[#FFE66D]" />
                数据管理
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">自动保存</p>
                    <p className="text-sm text-gray-500">自动保存对话历史</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={settings.autoSave}
                      onChange={(e) => updateSettings({ autoSave: e.target.checked })}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#FFE66D]" />
                  </label>
                </div>
                <button
                  onClick={() => setShowResetConfirm(true)}
                  className="w-full flex items-center justify-center gap-2 p-3 bg-red-500/10 text-red-400 rounded-xl hover:bg-red-500/20 transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                  清除所有数据
                </button>
              </div>
            </div>
          </div>
        )}

        {/* About Tab */}
        {activeTab === 'about' && (
          <div className="space-y-6">
            {/* App Info */}
            <div className="glass rounded-2xl p-8 border border-gray-800 text-center">
              <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#FF6B6B] to-[#4ECDC4] flex items-center justify-center mx-auto mb-6">
                <span className="text-4xl font-bold text-white">S</span>
              </div>
              <h2 className="text-2xl font-bold mb-2">studioPRO v2</h2>
              <p className="text-gray-500 mb-6">下一代 AI 创作工作台</p>
              <div className="flex items-center justify-center gap-4 text-sm text-gray-400">
                <span>版本 2.0.0</span>
                <span>·</span>
                <span>免费开源</span>
                <span>·</span>
                <span>无广告</span>
              </div>
            </div>

            {/* Features */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-4">功能特性</h3>
              <div className="grid grid-cols-2 gap-4">
                {[
                  'AI 对话聊天',
                  '代码生成助手',
                  '图像生成',
                  '多平台支持',
                  '本地数据存储',
                  '隐私保护'
                ].map((feature, index) => (
                  <div key={index} className="flex items-center gap-2 text-sm text-gray-400">
                    <Check className="w-4 h-4 text-green-400" />
                    {feature}
                  </div>
                ))}
              </div>
            </div>

            {/* Supported Platforms */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-4">支持的平台</h3>
              <div className="flex flex-wrap gap-3">
                {['OpenAI', 'Anthropic Claude', 'Google Gemini', 'DeepSeek', '自定义 API'].map((platform, index) => (
                  <span 
                    key={index}
                    className="px-3 py-1.5 bg-white/5 rounded-lg text-sm text-gray-400"
                  >
                    {platform}
                  </span>
                ))}
              </div>
            </div>

            {/* Disclaimer */}
            <div className="glass rounded-2xl p-6 border border-gray-800">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-yellow-400" />
                免责声明
              </h3>
              <p className="text-sm text-gray-500 leading-relaxed">
                本应用为第三方客户端，不隶属于任何 AI 平台。API 密钥仅存储在本地设备上，
                不会上传到任何服务器。使用本应用即表示你同意各 AI 平台的服务条款。
                AI 生成的内容仅供参考，请自行核实重要信息。
              </p>
            </div>
          </div>
        )}
      </main>

      {/* Reset Confirmation Modal */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="glass rounded-2xl p-6 max-w-sm w-full">
            <h3 className="text-xl font-bold mb-4">确认清除数据？</h3>
            <p className="text-gray-400 mb-6">
              此操作将删除所有对话历史、生成的图片和设置，且无法恢复。
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 btn-secondary"
              >
                取消
              </button>
              <button
                onClick={handleReset}
                className="flex-1 bg-red-500 text-white py-3 rounded-xl font-medium hover:bg-red-600 transition-colors"
              >
                确认清除
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
