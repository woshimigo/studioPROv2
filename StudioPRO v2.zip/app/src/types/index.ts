// AI Provider Types
export type AIProvider = 'openai' | 'anthropic' | 'gemini' | 'deepseek' | 'custom';

export interface APIConfig {
  provider: AIProvider;
  apiKey: string;
  apiUrl: string;
  model: string;
  enabled: boolean;
}

export interface ModelOption {
  id: string;
  name: string;
  provider: AIProvider;
  description: string;
}

// Message Types
export type MessageRole = 'user' | 'assistant' | 'system';

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: number;
  model?: string;
  images?: string[];
  codeBlocks?: CodeBlock[];
}

export interface CodeBlock {
  language: string;
  code: string;
}

// Chat Types
export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  model: string;
  provider: AIProvider;
  createdAt: number;
  updatedAt: number;
}

// AI Mode Types
export type AIMode = 'chat' | 'coder' | 'image';

export interface AIModeConfig {
  id: AIMode;
  name: string;
  description: string;
  icon: string;
  color: string;
  systemPrompt: string;
}

// Image Generation Types
export interface ImageGenerationParams {
  prompt: string;
  negativePrompt?: string;
  width?: number;
  height?: number;
  style?: string;
  steps?: number;
}

export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  timestamp: number;
  params: ImageGenerationParams;
}

// Settings Types
export interface AppSettings {
  theme: 'dark' | 'light' | 'auto';
  language: string;
  defaultModel: string;
  defaultProvider: AIProvider;
  apiConfigs: APIConfig[];
  imageProvider: 'openai' | 'stability' | 'custom';
  imageApiKey: string;
  imageApiUrl: string;
  soundEnabled: boolean;
  vibrationEnabled: boolean;
  autoSave: boolean;
}

// User Types
export interface UserProfile {
  id: string;
  name: string;
  avatar?: string;
  email?: string;
  createdAt: number;
}

// Navigation Types
export type Page = 'home' | 'chat' | 'settings' | 'history';

// Preset Types
export interface AIPreset {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  mode: AIMode;
  systemPrompt: string;
  welcomeMessage: string;
}

// Toast Types
export type ToastType = 'success' | 'error' | 'info' | 'warning';

export interface Toast {
  id: string;
  type: ToastType;
  message: string;
  duration?: number;
}

// Stream Response Types
export interface StreamChunk {
  content?: string;
  done?: boolean;
  error?: string;
}
